import pickle
import streamlit as st

print('Successfully executed till here')

# loading the saved models

loan_model = pickle.load(open('loan_prediction_model.pkl', 'rb'))



# page title
st.title('Loan Prediction_Rohit')
    
    
# getting the input data from the user
col1, col2, col3, col4,col5,col6,col7,col8,col9,col10,col11,col12,col13= st.columns(13)
    
#with col1:
    #Loan_ID = st.text_input('Enter Loan ID')
with col2:
    Gender = st.text_input('Gender')
with col3:
    Married = st.text_input('Married')
with col4:
    Dependents = st.text_input('Dependents')
with col5:
    Education = st.text_input('Education Level')
with col6:
    Self_Employed = st.text_input('Self_Employment status')
with col7:
    ApplicantIncome = st.text_input('Applicant Income')
with col8:
    CoapplicantIncome = st.text_input('Co Applicant Name')
with col9:
    Loan_Amount = st.text_input('Loan Amount')
with col10:
    Loan_Amount_Term = st.text_input('Term for Loan Amount')
with col11:
    Credit_History = st.text_input('Credit history')
with col12:
    Property_Area =  st.text_input('Property Area')
with col13:
    Loan_Status =  st.text_input('Loan_Status')
    
    # code for Prediction
    load_diagonsis = ''
    
    # creating a button for Prediction
    
    if st.button('Loan Test Result'):
        load_diagonsis = loan_model.predict([['Gender','Married','Dependents','Education','Self_Employed',
                                              'ApplicantIncome','CoapplicantIncome','LoanAmount',
                                              'Loan_Amount_Term','Credit_History',
                                              'Property_Area']])
        
        if (loan_diagonsis[0] == 1):
          load_diagonsis = 'Loan approved'
        else:
          load_diagonsis = 'Loan Disapproved'
        
    st.success(load_diagonsis)